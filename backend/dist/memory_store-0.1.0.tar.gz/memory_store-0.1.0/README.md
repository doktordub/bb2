# Memory Store

`memory-store` is a local-first Python memory system for AI agents. It keeps persistence inside ArcadeDB Embedded, exposes a Python-first API through `MemoryStore`, supports deterministic markdown ingestion, hybrid retrieval with explainable scoring, lifecycle transitions, privacy controls, and thin REST/CLI adapters over the same service layer.

See [docs/architecture.md](docs/architecture.md) for the system design and [docs/plan.md](docs/plan.md) for the phased build plan.

## What It Does

- Stores agent memories, project facts, decisions, task state, and document chunks locally.
- Ingests markdown files deterministically with stable chunk IDs and re-ingestion behavior.
- Searches with full-text + vector retrieval + reciprocal rank fusion + optional reranking.
- Preserves raw scores, normalized scores, and debug metadata on every result.
- Applies lifecycle and privacy rules before results are returned to agents or adapters.

## When To Use It

- You want local memory without a hosted vector database.
- You need one shared service layer behind Python, REST, and CLI surfaces.
- You want explainable retrieval with inspectable score components.
- You need deterministic markdown ingestion for docs, notes, or repo memory.

## When Not To Use It

- You need multi-node, distributed, or multi-writer coordination.
- You need a hosted SaaS memory service or managed vector infrastructure.
- You need multi-hop graph traversal beyond one hop.
- You need a UI dashboard or production auth model beyond a local API token.

## V1 Boundaries And Non-Goals

- Single-process embedded persistence only.
- ArcadeDB Embedded is the only persistence backend.
- FastEmbed is the only embedding and reranking provider in V1.
- REST and CLI are optional thin adapters, not separate business-logic stacks.
- No distributed sync, hosted vector DBs, or workflow orchestration framework.

## Installation

```powershell
.\.venv\Scripts\python.exe -m pip install -e .[dev]
```

If you want to start from the sample configuration, copy `config.example.yaml` to a local config file and adjust the database path, API token, or retrieval settings as needed.

## Quickstart With The Python API

```python
from memory_store import MemoryStore, Scope
from memory_store.models import MemoryCreate, MemorySearchQuery, MemoryType

store = MemoryStore.from_config(
	database={"path": "./data/quickstart", "schema_version": 1},
	reranker={"enabled": False},
)

try:
	scope = Scope(project_id="arcade")
	record = store.add_memory(
		MemoryCreate(
			scope=scope,
			stable_key="decision_fastembed_reranker",
			memory_type=MemoryType.DECISION,
			title="Use FastEmbed reranking",
			text="We chose FastEmbed cross-encoder reranking for bounded hybrid search.",
		)
	)
	results = store.search(
		MemorySearchQuery(scope=scope, text="What reranking approach did we choose?", limit=3)
	)
	print(record.memory_id)
	print(results[0].memory.memory_id if results else "no results")
finally:
	store.close()
```

Runnable version: [examples/python_api_example.py](examples/python_api_example.py)

## Markdown Ingestion Example

```python
from pathlib import Path

from memory_store import MemoryStore, Scope

store = MemoryStore.from_config(database={"path": "./data/docs", "schema_version": 1})

try:
	scope = Scope(project_id="docs")
	ingest_result = store.ingest_document(Path("docs/architecture.md"), scope)
	matches = store.search_document_chunks(text="hybrid retrieval", scope=scope, limit=3)
	print(ingest_result)
	if matches:
		context = store.get_chunk_context(matches[0].chunk_id, scope=scope, before=1, after=1)
		print(matches[0].chunk_id)
		print(matches[0].metadata["approximate_token_count"])
		print(len(context.before), len(context.after))
finally:
	store.close()
```

Runnable version: [examples/markdown_ingest_example.py](examples/markdown_ingest_example.py)

`chunking.max_tokens` and `chunking.overlap_tokens` are approximate whitespace-token budgets. Persisted document chunks expose `metadata.approximate_token_count` plus the applied chunking settings so callers can inspect why a chunk is the size it is.

## Hybrid Retrieval Example

Hybrid retrieval in V1 runs these stages in order:

1. Vector candidate search.
2. Full-text candidate search.
3. Reciprocal rank fusion.
4. Deduplication and optional one-hop graph expansion.
5. Optional reranking on a bounded candidate set.
6. Final scoring with raw and normalized diagnostics preserved.

```python
results = store.search(
	MemorySearchQuery(scope=Scope(project_id="arcade"), text="service layer adapters", limit=5)
)

for result in results:
	print(result.memory.memory_id, result.final_score)
	print(result.component_scores)
	print(result.normalized_scores)
	print(result.debug)
```

## REST API Example

To launch the FastAPI adapter with the app factory:

```powershell
.\.venv\Scripts\python.exe -m uvicorn memory_store.api.main:create_app --factory --host 127.0.0.1 --port 8080
```

Example requests:

```powershell
curl http://127.0.0.1:8080/health

curl -X POST http://127.0.0.1:8080/memories/search ^
  -H "Content-Type: application/json" ^
  -d "{\"scope\": {\"project_id\": \"arcade\"}, \"text\": \"service layer\"}"

curl -X POST http://127.0.0.1:8080/chunks/search ^
	-H "Content-Type: application/json" ^
	-d "{\"scope\": {\"project_id\": \"arcade\"}, \"text\": \"hybrid retrieval\", \"before\": 1, \"after\": 1}"

curl "http://127.0.0.1:8080/chunks/chunk-id/context?project_id=arcade&before=1&after=1"
```

Runnable in-process example: [examples/rest_example.py](examples/rest_example.py)

## CLI Examples

```powershell
memory-store init --config config.example.yaml
memory-store ingest-file docs/architecture.md --project-id arcade
memory-store ingest-folder docs/ --project-id arcade
memory-store search "What reranking approach did we choose?" --project-id arcade
memory-store search-chunks "hybrid retrieval" --project-id arcade
memory-store chunk-context chunk-id --project-id arcade --before 1 --after 1
memory-store export --user-id user-1 --out memories.json
memory-store delete-by-scope --project-id arcade --dry-run
memory-store eval evals/golden_queries.yaml
```

## Configuration Reference

Configuration precedence is:

```text
defaults < config.yaml < environment variables < explicit code overrides
```

Main sections in [config.example.yaml](config.example.yaml):

- `database`: local path, schema version, and create-if-missing behavior.
- `embeddings`: FastEmbed model, batch size, dimension policy.
- `reranker`: enable/disable, model, and bounded `top_n` size.
- `retrieval`: vector/FTS fan-out, RRF constant, graph expansion, debug toggles.
- `scoring`: weight map and per-memory-type temporal behavior.
- `chunking`: markdown chunking strategy, approximate token budgets, overlap, and heading-path handling.
- `privacy`: default retrieval/context flags and scope delete safety.
- `api`: host, port, and optional local API token.
- `logging`: current log level.

Environment variables use `MEMORY_STORE_` with double underscores, for example:

```powershell
$env:MEMORY_STORE_DATABASE__PATH = "./data/dev-memory"
$env:MEMORY_STORE_API__LOCAL_API_TOKEN = "dev-token"
```

## Lifecycle Examples

```python
record = store.add_memory(MemoryCreate(scope=Scope(project_id="arcade"), text="Candidate note"))
promoted = store.promote(record.memory_id, reason="confirmed during eval")

newer = store.add_memory(
	MemoryCreate(scope=Scope(project_id="arcade"), text="Updated decision", stable_key="decision:new")
)
store.supersede(promoted.memory_id, newer.memory_id, reason="replaced by new rollout rule")
store.expire(newer.memory_id, reason="time-boxed experiment ended")
store.add_feedback(newer.memory_id, MemoryFeedback(positive=True, confidence=0.9))
```

## Privacy, Delete, Export, And Import Examples

```python
scope = Scope(project_id="arcade", user_id="user-1")
export_payload = store.export_scope(scope)
store.import_memories(MemoryImport(records=export_payload.records, source="backup"), mode="upsert")
store.forget("memory-id")
store.delete_by_scope(Scope(project_id="arcade"), hard_delete=False)
store.redact([r"secret-[0-9]+"], scope=Scope(project_id="arcade"))
```

## Eval Runner Example

The eval runner loads a golden query fixture, executes searches, records latency and retrieval diagnostics, and writes both a JSON summary and a Markdown report.

```powershell
memory-store eval evals/golden_queries.yaml
```

Outputs:

- `evals/golden_queries.summary.json`
- `evals/golden_queries.report.md`

Metrics included by V1:

- Recall@10
- MRR
- NDCG
- Latency p50/p95
- Reranker time plus input-document count as the local cost proxy
- Duplicate rate
- Stale memory rate

Runnable version: [examples/eval_runner_example.py](examples/eval_runner_example.py)

## Local Development And Validation

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m ruff check memory_store evals examples tests
.\.venv\Scripts\python.exe -m mypy memory_store tests
```

## Known V1 Limitations

- Single-process embedded persistence only.
- One-hop graph expansion only.
- No hosted or distributed sync layer.
- REST authentication is limited to an optional local API token.
- Golden query fixtures are intentionally project-specific; update `evals/golden_queries.yaml` as your corpus evolves.
- On Windows, `arcadedb_embedded` via JPype can emit `Windows fatal exception: access violation` during some threaded pytest flows even when the process exit code is `0`. Treat the command exit code as the source of truth.
