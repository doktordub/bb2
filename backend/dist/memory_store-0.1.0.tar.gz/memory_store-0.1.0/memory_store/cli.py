"""Thin command-line adapter over the shared service layer."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Sequence

from .api.schemas import to_jsonable
from .models import MemoryExport, MemorySearchQuery, Scope
from .store import MemoryStore


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="memory-store")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--config", type=Path, default=None)

    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("health", parents=[common])
    subparsers.add_parser("init", parents=[common])

    ingest_file = subparsers.add_parser("ingest-file", parents=[common])
    ingest_file.add_argument("path", type=Path)
    _add_scope_arguments(ingest_file)

    ingest_folder = subparsers.add_parser("ingest-folder", parents=[common])
    ingest_folder.add_argument("path", type=Path)
    _add_scope_arguments(ingest_folder)

    search = subparsers.add_parser("search", parents=[common])
    search.add_argument("query")
    search.add_argument("--limit", type=int, default=10)
    _add_scope_arguments(search)

    search_chunks = subparsers.add_parser("search-chunks", parents=[common])
    search_chunks.add_argument("query")
    search_chunks.add_argument("--limit", type=int, default=10)
    _add_scope_arguments(search_chunks)

    chunk_context = subparsers.add_parser("chunk-context", parents=[common])
    chunk_context.add_argument("chunk_id")
    chunk_context.add_argument("--before", type=int, default=1)
    chunk_context.add_argument("--after", type=int, default=1)
    _add_scope_arguments(chunk_context)

    evaluate = subparsers.add_parser("eval", parents=[common])
    evaluate.add_argument("path", nargs="?", type=Path, default=Path("evals/golden_queries.yaml"))

    export = subparsers.add_parser("export", parents=[common])
    export.add_argument("--out", type=Path, required=True)
    _add_scope_arguments(export)

    delete_by_scope = subparsers.add_parser("delete-by-scope", parents=[common])
    delete_by_scope.add_argument("--dry-run", action="store_true")
    delete_by_scope.add_argument("--hard-delete", action="store_true")
    _add_scope_arguments(delete_by_scope)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "eval":
        try:
            result = run_evaluation(args.path, config_path=args.config)
        except ModuleNotFoundError as exc:
            if exc.name == "evals" or exc.name.startswith("evals."):
                parser.error(
                    "The eval command requires the repository eval modules. "
                    "Install from source with `pip install -e .[dev]` or run from the project root."
                )
            raise
        print(str(result).replace("\\", "/"))
        return 0

    store = MemoryStore.from_config(args.config)

    try:
        if args.command in {"health", "init"}:
            _print_json(store.health())
            return 0

        if args.command == "ingest-file":
            _print_json(store.ingest_document(args.path, _scope_from_args(args)))
            return 0

        if args.command == "ingest-folder":
            _print_json(store.ingest_folder(args.path, _scope_from_args(args)))
            return 0

        if args.command == "search":
            _print_json(
                store.search(
                    MemorySearchQuery(
                        scope=_scope_from_args(args),
                        text=args.query,
                        limit=args.limit,
                    )
                )
            )
            return 0

        if args.command == "search-chunks":
            _print_json(
                store.search_document_chunks(
                    text=args.query,
                    scope=_scope_from_args(args),
                    limit=args.limit,
                )
            )
            return 0

        if args.command == "chunk-context":
            _print_json(
                store.get_chunk_context(
                    args.chunk_id,
                    scope=_scope_from_args(args),
                    before=args.before,
                    after=args.after,
                )
            )
            return 0

        if args.command == "export":
            payload = _export_payload(store, _scope_from_args(args))
            args.out.write_text(_to_json(payload), encoding="utf-8")
            _print_json(payload)
            return 0

        if args.command == "delete-by-scope":
            scope = _scope_from_args(args)
            if scope.is_global:
                parser.error(
                    "delete-by-scope requires at least one of --user-id, "
                    "--project-id, or --agent-id"
                )

            if args.dry_run:
                preview = store.export_scope(scope)
                _print_json(
                    {
                        "count": len(preview.records),
                        "dry_run": True,
                        "hard_delete": args.hard_delete,
                        "scope": scope,
                    }
                )
                return 0

            _print_json(
                {
                    "deleted": store.delete_by_scope(scope, hard_delete=args.hard_delete),
                    "dry_run": False,
                    "hard_delete": args.hard_delete,
                    "scope": scope,
                }
            )
            return 0
    finally:
        close = getattr(store, "close", None)
        if callable(close):
            close()

    parser.error(f"Unsupported command: {args.command}")
    return 2


def _add_scope_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--user-id")
    parser.add_argument("--project-id")
    parser.add_argument("--agent-id")


def _scope_from_args(args: argparse.Namespace) -> Scope:
    return Scope(
        user_id=getattr(args, "user_id", None),
        project_id=getattr(args, "project_id", None),
        agent_id=getattr(args, "agent_id", None),
    )


def run_evaluation(path: Path, config_path: Path | None = None) -> Any:
    from evals.runner import run

    return run(path, config_path=config_path)


def _export_payload(store: MemoryStore, scope: Scope) -> MemoryExport:
    if scope.user_id is not None and scope.project_id is None and scope.agent_id is None:
        return MemoryExport(scope=scope, records=store.export_user_memories(scope.user_id))
    return store.export_scope(scope)


def _to_json(payload: Any) -> str:
    return json.dumps(to_jsonable(payload), indent=2, sort_keys=True)


def _print_json(payload: Any) -> None:
    print(_to_json(payload))


if __name__ == "__main__":
    raise SystemExit(main())
