"""Shared service layer used by both direct Python calls and adapters."""

from __future__ import annotations

from contextlib import suppress
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, NoReturn

from .arcade import (
    ArcadeConnectionSettings,
    ArcadeMemoryRepository,
    arcade_runtime_available,
    ensure_database_schema,
    open_arcade_database,
    read_schema_version,
)
from .arcade.connection import ArcadeDatabaseHandle
from .arcade.transactions import run_in_transaction
from .config import MemoryStoreSettings, load_settings
from .embeddings import (
    FastEmbedProvider,
    build_embedding_text,
    fastembed_runtime_available,
    validate_active_index_dimension,
    validate_embedding_dimensions,
)
from .errors import (
    EmbeddingDimensionMismatchError,
    IngestionError,
    MemoryNotFoundError,
    MemoryStoreError,
    PersistenceError,
    RetrievalError,
)
from .ingestion import (
    chunk_markdown_sections,
    compute_chunk_id,
    compute_content_hash,
    compute_source_hash,
    normalize_source_path,
    read_markdown_file,
)
from .lifecycle import MemoryLifecycleManager
from .models import (
    ChunkContextResponse,
    ChunkSearchResult,
    FolderIngestResult,
    HealthStatus,
    ImportMode,
    ImportResult,
    IngestResult,
    MemoryCreate,
    MemoryExport,
    MemoryFeedback,
    MemoryImport,
    MemoryRecord,
    MemorySearchQuery,
    MemorySearchResult,
    MemoryStats,
    MemoryStatus,
    MemoryType,
    MemoryUpdate,
    RedactionResult,
    Scope,
    SourceType,
)
from .privacy import PrivacyController
from .retrieval import (
    build_hard_filter,
    deduplicate_candidates,
    expand_one_hop_candidates,
    filter_records,
    normalize_query,
    reciprocal_rank_fuse,
    rerank_candidates,
    search_full_text,
    search_vectors,
)
from .scoring import enrich_candidate_scores, normalize_candidate_scores, score_candidates


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class MemoryService:
    """Service layer with a shared ArcadeDB-backed repository."""

    def __init__(self, settings: MemoryStoreSettings | None = None) -> None:
        self.settings = settings or MemoryStoreSettings()
        self._database_handle: ArcadeDatabaseHandle | None = None
        self._repository_instance: ArcadeMemoryRepository | None = None
        self._embedding_provider_instance: FastEmbedProvider | None = None
        self._lifecycle_manager_instance: MemoryLifecycleManager | None = None
        self._privacy_controller_instance: PrivacyController | None = None
        self._active_embedding_dimension: int | None = None
        self._schema_version = self.settings.database.schema_version
        self._ensure_repository()

    @classmethod
    def from_config(
        cls,
        config_path: str | Path | None = None,
        **overrides: Any,
    ) -> "MemoryService":
        return cls(load_settings(config_path, **overrides))

    def close(self) -> None:
        handle = self._database_handle
        self._database_handle = None
        self._repository_instance = None
        self._lifecycle_manager_instance = None
        if handle is not None:
            handle.close()

    def __enter__(self) -> "MemoryService":
        return self

    def __exit__(self, exc_type: object, exc: object, exc_tb: object) -> None:
        self.close()

    def add_memory(self, memory: MemoryCreate, *, embed: bool = False) -> MemoryRecord:
        prepared = self._prepare_memory_for_write(
            self._apply_service_defaults(memory),
            embed=embed,
        )
        return self._repository().insert_memory(prepared)

    def get_memory(self, memory_id: str) -> MemoryRecord | None:
        return self._repository().get_memory(memory_id)

    def update_memory(self, memory_id: str, patch: MemoryUpdate) -> MemoryRecord:
        return self._repository().update_memory(memory_id, patch)

    def upsert_memory(
        self,
        memory: MemoryCreate,
        stable_key: str | None = None,
        *,
        embed: bool = False,
    ) -> MemoryRecord:
        return self._repository().upsert_memory(
            self._prepare_memory_for_write(self._apply_service_defaults(memory), embed=embed),
            stable_key=stable_key,
        )

    def search(self, query: MemorySearchQuery) -> list[MemorySearchResult]:
        repository = self._repository()
        try:
            normalized_query = normalize_query(query)
            hard_filter = build_hard_filter(query)
            records = filter_records(repository.list_by_scope(query.scope), query)
            if not records:
                return []

            vector_matches = search_vectors(
                records,
                normalized_query,
                top_n=self.settings.retrieval.vector_top_n,
                embed_query=self._embed_search_query,
            )
            full_text_matches = search_full_text(
                records,
                normalized_query,
                top_n=self.settings.retrieval.fts_top_n,
            )

            candidates = reciprocal_rank_fuse(
                vector_matches=vector_matches,
                full_text_matches=full_text_matches,
                rrf_k=self.settings.retrieval.rrf_k,
            )
            if not candidates:
                return []

            candidates = deduplicate_candidates(candidates)

            if (
                self.settings.retrieval.graph_expansion_enabled
                and self.settings.retrieval.graph_expansion_hops > 0
            ):
                candidates = expand_one_hop_candidates(
                    candidates,
                    hard_filter=hard_filter,
                    read_links=lambda memory_id: repository.read_one_hop_links(memory_id),
                )
                candidates = deduplicate_candidates(candidates)

            enrich_candidate_scores(
                candidates,
                temporal_settings=self.settings.scoring.temporal,
                now=_utcnow(),
            )
            weight_map = self._scoring_weights()
            normalize_candidate_scores(candidates)
            score_candidates(
                candidates,
                weight_map,
                reranker_enabled=self.settings.reranker.enabled,
            )
            candidates.sort(
                key=lambda candidate: (
                    -candidate.final_score,
                    -candidate.component_scores.get("retrieval_fusion", 0.0),
                    candidate.memory.memory_id,
                )
            )

            rerank_candidates(
                candidates,
                query_text=normalized_query.text,
                enabled=self.settings.reranker.enabled,
                model=self.settings.reranker.model,
                top_n=min(self.settings.reranker.top_n, len(candidates)),
            )

            normalize_candidate_scores(candidates)
            score_candidates(
                candidates,
                weight_map,
                reranker_enabled=self.settings.reranker.enabled,
            )
            candidates.sort(
                key=lambda candidate: (
                    -candidate.final_score,
                    -candidate.component_scores.get("retrieval_fusion", 0.0),
                    candidate.memory.memory_id,
                )
            )

            limit = min(query.limit, self.settings.retrieval.final_top_k)
            return [
                candidate.to_result(
                    include_component_scores=self.settings.retrieval.include_component_scores,
                    include_debug=self.settings.retrieval.include_debug,
                )
                for candidate in candidates[:limit]
            ]
        except MemoryStoreError:
            raise
        except Exception as exc:
            raise RetrievalError(f"Search failed: {exc}") from exc

    def search_document_chunks(
        self,
        *,
        text: str,
        scope: Scope,
        limit: int = 10,
        before: int = 0,
        after: int = 0,
        include_removed: bool = False,
        allow_retrieval_only: bool = True,
    ) -> list[ChunkSearchResult]:
        results = self.search(
            MemorySearchQuery(
                scope=scope,
                text=text,
                limit=limit,
                memory_types=[MemoryType.DOCUMENT_CHUNK],
                include_removed=include_removed,
                allow_retrieval_only=allow_retrieval_only,
            )
        )
        return [ChunkSearchResult.from_search_result(result) for result in results]

    def get_chunk(self, chunk_id: str, *, scope: Scope | None = None) -> ChunkSearchResult | None:
        record = self._repository().get_chunk_by_id(chunk_id, scope=scope)
        if record is None:
            return None
        return ChunkSearchResult.from_record(record, debug={"lookup": "chunk_id"})

    def get_chunk_context(
        self,
        chunk_id: str,
        *,
        scope: Scope | None = None,
        before: int = 0,
        after: int = 0,
    ) -> ChunkContextResponse:
        record = self._repository().get_chunk_by_id(chunk_id, scope=scope)
        if record is None:
            raise MemoryNotFoundError(f"Document chunk was not found: {chunk_id}")
        if record.source_path is None or record.document_chunk_index is None:
            raise RetrievalError(
                "Document chunk context requires source_path and document_chunk_index."
            )

        resolved_scope = scope or record.scope
        window = self._repository().list_chunk_window(
            record.source_path,
            scope=resolved_scope,
            document_chunk_index=record.document_chunk_index,
            before=before,
            after=after,
        )

        target = ChunkSearchResult.from_record(record, debug={"lookup": "chunk_context"})
        before_chunks: list[ChunkSearchResult] = []
        after_chunks: list[ChunkSearchResult] = []

        for window_record in window:
            chunk = ChunkSearchResult.from_record(
                window_record,
                debug={"lookup": "chunk_context"},
            )
            if window_record.memory_id == record.memory_id:
                target = chunk
                continue
            if (window_record.document_chunk_index or -1) < record.document_chunk_index:
                before_chunks.append(chunk)
                continue
            after_chunks.append(chunk)

        return ChunkContextResponse(
            chunk=target,
            before=before_chunks,
            after=after_chunks,
        )

    def ingest_document(self, path: str | Path, scope: Scope) -> IngestResult:
        repository = self._repository()
        document_path = Path(path)
        parsed = read_markdown_file(document_path)
        source_path = normalize_source_path(document_path)
        chunks = chunk_markdown_sections(
            parsed.sections,
            strategy=self.settings.chunking.strategy,
            max_tokens=self.settings.chunking.max_tokens,
            overlap_tokens=self.settings.chunking.overlap_tokens,
            include_heading_path=self.settings.chunking.include_heading_path,
            preserve_code_blocks=self.settings.chunking.preserve_code_blocks,
        )

        existing_chunks = repository.list_by_source_path(
            source_path,
            scope=scope,
            memory_type=MemoryType.DOCUMENT_CHUNK,
        )
        existing_by_source_hash = {
            record.source_hash: record
            for record in existing_chunks
            if record.source_hash is not None
        }

        planned_source_hashes: set[str] = set()
        inserts: list[MemoryCreate] = []
        replacements: list[tuple[MemoryRecord, MemoryCreate]] = []
        unchanged = 0

        for document_chunk_index, chunk in enumerate(chunks):
            source_hash = compute_source_hash(source_path, chunk.heading_path, chunk.chunk_index)
            planned_source_hashes.add(source_hash)

            candidate = self._build_document_chunk_memory(
                scope=scope,
                source_path=source_path,
                parsed_document=parsed,
                heading_path=chunk.heading_path,
                section_index=chunk.section_index,
                chunk_index=chunk.chunk_index,
                document_chunk_index=document_chunk_index,
                text=chunk.text,
                approximate_tokens=chunk.approximate_token_count,
                source_hash=source_hash,
            )

            existing = existing_by_source_hash.get(source_hash)
            content_hash = candidate.metadata["content_hash"]
            if (
                existing is not None
                and existing.chunk_id == candidate.chunk_id
                and existing.metadata.get("content_hash") == content_hash
                and existing.status == MemoryStatus.ACTIVE
                and existing.allow_retrieval
                and existing.allow_llm_context
            ):
                unchanged += 1
                continue

            prepared = self._prepare_memory_for_write(candidate, embed=True)
            if existing is None:
                inserts.append(prepared)
            else:
                replacements.append((existing, prepared))

        removals = [
            record
            for source_hash, record in existing_by_source_hash.items()
            if source_hash not in planned_source_hashes
            and record.status not in {MemoryStatus.REMOVED, MemoryStatus.DELETED}
        ]

        removed = self._persist_document_ingestion(
            inserts=inserts,
            replacements=replacements,
            removals=removals,
        )

        return IngestResult(
            path=document_path,
            added=len(inserts),
            updated=len(replacements),
            removed=removed,
            unchanged=unchanged,
        )

    def ingest_folder(self, path: str | Path, scope: Scope) -> FolderIngestResult:
        root = Path(path)
        if not root.exists() or not root.is_dir():
            raise IngestionError(f"Markdown folder was not found: {root}")

        markdown_files = sorted(
            child
            for child in root.rglob("*")
            if child.is_file() and child.suffix.lower() in {".md", ".markdown"}
        )

        result = FolderIngestResult(root=root)
        for markdown_file in markdown_files:
            file_result = self.ingest_document(markdown_file, scope)
            result.files_processed += 1
            result.added += file_result.added
            result.updated += file_result.updated
            result.removed += file_result.removed
            result.unchanged += file_result.unchanged
        return result

    def promote(self, memory_id: str, reason: str | None = None) -> MemoryRecord:
        return self._lifecycle().promote(memory_id, reason=reason)

    def supersede(
        self,
        old_memory_id: str,
        new_memory_id: str,
        reason: str | None = None,
    ) -> None:
        self._lifecycle().supersede(old_memory_id, new_memory_id, reason=reason)

    def contradict(self, memory_id_a: str, memory_id_b: str, reason: str | None = None) -> None:
        self._lifecycle().contradict(memory_id_a, memory_id_b, reason=reason)

    def expire(self, memory_id: str, reason: str | None = None) -> None:
        self._lifecycle().expire(memory_id, reason=reason)

    def forget(self, memory_id: str) -> None:
        self._privacy().forget(memory_id)

    def forget_by_user(self, user_id: str) -> int:
        return self._privacy().forget_by_user(user_id)

    def delete_by_scope(self, scope: Scope, hard_delete: bool = False) -> int:
        return self._privacy().delete_by_scope(scope, hard_delete=hard_delete)

    def disable_memory(self, scope: Scope) -> int:
        return self._privacy().disable_memory(scope)

    def export_user_memories(self, user_id: str) -> list[MemoryRecord]:
        return self._privacy().export_user_memories(user_id)

    def export_scope(self, scope: Scope) -> MemoryExport:
        return self._privacy().export_scope(scope)

    def import_memories(self, payload: MemoryImport, mode: ImportMode = "upsert") -> ImportResult:
        return self._privacy().import_memories(payload, mode=mode)

    def redact(self, patterns: list[str], scope: Scope | None = None) -> RedactionResult:
        return self._privacy().redact(patterns, scope=scope)

    def add_feedback(self, memory_id: str, feedback: MemoryFeedback) -> MemoryRecord:
        return self._lifecycle().add_feedback(memory_id, feedback)

    def stats(self) -> MemoryStats:
        repository = self._repository()
        total_records = repository.count_memories()
        global_records = repository.count_memories(scope=Scope())

        status_counts = {
            status.value: count
            for status in MemoryStatus
            if (count := repository.count_memories(status=status)) > 0
        }
        type_counts = {
            memory_type.value: count
            for memory_type in MemoryType
            if (count := repository.count_memories(memory_type=memory_type)) > 0
        }

        return MemoryStats(
            total_records=total_records,
            scope_counts={
                "global": global_records,
                "scoped": total_records - global_records,
            },
            status_counts=status_counts,
            type_counts=type_counts,
        )

    def health(self) -> HealthStatus:
        repository = self._repository()
        handle = self._database_handle
        if handle is None:
            raise PersistenceError("Database handle is not available.")

        return HealthStatus(
            status="ok" if handle.database.is_open() else "degraded",
            database_path=handle.database_path,
            schema_version=read_schema_version(repository.database) or self._schema_version,
            dependencies={
                "arcadedb_embedded": arcade_runtime_available(),
                "fastembed": fastembed_runtime_available(),
            },
            message="Core CRUD, health, and stats APIs are ready.",
        )

    def _repository(self) -> ArcadeMemoryRepository:
        self._ensure_repository()
        if self._repository_instance is None:
            raise PersistenceError("Repository is not available.")
        return self._repository_instance

    def _build_document_chunk_memory(
        self,
        *,
        scope: Scope,
        source_path: str,
        parsed_document: Any,
        heading_path: tuple[str, ...],
        section_index: int,
        chunk_index: int,
        document_chunk_index: int,
        text: str,
        approximate_tokens: int,
        source_hash: str,
    ) -> MemoryCreate:
        metadata = {
            "frontmatter": dict(parsed_document.frontmatter),
            "document_lifecycle": "source_controlled",
            "section_index": section_index,
            "section_chunk_index": chunk_index,
            "document_chunk_index": document_chunk_index,
            "approximate_token_count": approximate_tokens,
            "chunking_max_tokens": self.settings.chunking.max_tokens,
            "chunking_overlap_tokens": self.settings.chunking.overlap_tokens,
            "chunking_max_tokens_is_approximate": True,
            "chunking_preserve_code_blocks": self.settings.chunking.preserve_code_blocks,
        }
        if heading_path:
            metadata["heading_path_text"] = " > ".join(heading_path)
        if parsed_document.frontmatter.get("owner") is not None:
            metadata["owner"] = parsed_document.frontmatter["owner"]

        base_memory = MemoryCreate(
            scope=scope,
            stable_key=source_hash,
            memory_type=MemoryType.DOCUMENT_CHUNK,
            status=MemoryStatus.ACTIVE,
            title=parsed_document.title,
            summary=parsed_document.description,
            text=text,
            tags=list(parsed_document.tags),
            source_type=SourceType.DOCUMENT,
            source_path=source_path,
            source_hash=source_hash,
            heading_path=list(heading_path) or None,
            section_index=section_index,
            section_chunk_index=chunk_index,
            document_chunk_index=document_chunk_index,
            chunk_index=chunk_index,
            allow_retrieval=True,
            allow_llm_context=True,
            metadata=metadata,
        )

        content_hash = compute_content_hash(
            build_embedding_text(
                base_memory,
                include_heading_path=self.settings.chunking.include_heading_path,
                include_frontmatter=self.settings.chunking.include_frontmatter_in_embedding,
            )
        )
        chunk_id = compute_chunk_id(source_path, heading_path, chunk_index, content_hash)

        return base_memory.model_copy(
            update={
                "chunk_id": chunk_id,
                "metadata": {
                    **metadata,
                    "content_hash": content_hash,
                },
            }
        )

    def _persist_document_ingestion(
        self,
        *,
        inserts: list[MemoryCreate],
        replacements: list[tuple[MemoryRecord, MemoryCreate]],
        removals: list[MemoryRecord],
    ) -> int:
        repository = self._repository()
        removed_count = len(removals)

        def _operation() -> None:
            for memory in inserts:
                repository._insert_memory(memory, use_transaction=False)

            for existing, replacement in replacements:
                stable_key = replacement.stable_key or existing.stable_key or existing.source_hash
                if stable_key is None:
                    raise PersistenceError(
                        "Document chunk replacement requires a stable logical key."
                    )
                merged = repository._replace_record(existing, replacement, stable_key=stable_key)
                repository._persist_existing(merged, use_transaction=False)

            for record in removals:
                if self.settings.chunking.removed_chunk_policy == "hard_delete":
                    repository._delete_memory(record.memory_id, use_transaction=False)
                    continue

                metadata = dict(record.metadata)
                metadata["document_removed"] = True
                repository._update_memory(
                    record.memory_id,
                    MemoryUpdate(
                        status=MemoryStatus.REMOVED,
                        allow_retrieval=False,
                        allow_llm_context=False,
                        metadata=metadata,
                    ),
                    use_transaction=False,
                )

        run_in_transaction(repository.database, _operation)
        return removed_count

    def _ensure_repository(self) -> None:
        if self._database_handle is not None and self._repository_instance is not None:
            return

        embedding_dimensions = self.settings.embeddings.dim
        if embedding_dimensions is None:
            raise PersistenceError(
                "MemoryStoreSettings.embeddings.dim must be set to initialize the database schema."
            )

        handle = open_arcade_database(
            ArcadeConnectionSettings.from_database_settings(self.settings.database)
        )

        try:
            self._schema_version = ensure_database_schema(
                handle.database,
                expected_version=self.settings.database.schema_version,
                embedding_dimensions=embedding_dimensions,
            )
            self._active_embedding_dimension = validate_active_index_dimension(
                handle.database,
                embedding_dimensions,
            )
        except Exception:
            with suppress(PersistenceError):
                handle.close()
            raise

        self._database_handle = handle
        self._repository_instance = ArcadeMemoryRepository(
            handle.database,
            schema_version=self._schema_version,
        )
        self._lifecycle_manager_instance = None
        self._privacy_controller_instance = None

    def _lifecycle(self) -> MemoryLifecycleManager:
        if self._lifecycle_manager_instance is None:
            self._lifecycle_manager_instance = MemoryLifecycleManager(self._repository())
        return self._lifecycle_manager_instance

    def _privacy(self) -> PrivacyController:
        if self._privacy_controller_instance is None:
            self._privacy_controller_instance = PrivacyController(
                self._repository(),
                lifecycle=self._lifecycle(),
                settings=self.settings.privacy,
            )
        return self._privacy_controller_instance

    def _apply_service_defaults(self, memory: MemoryCreate) -> MemoryCreate:
        updates: dict[str, Any] = {}

        if "sensitivity" not in memory.model_fields_set:
            updates["sensitivity"] = self.settings.privacy.default_sensitivity
        if "allow_retrieval" not in memory.model_fields_set:
            updates["allow_retrieval"] = self.settings.privacy.allow_retrieval_default
        if "allow_llm_context" not in memory.model_fields_set:
            updates["allow_llm_context"] = self.settings.privacy.allow_llm_context_default
        if memory.embedding is not None and memory.embedding_dim is None:
            updates["embedding_dim"] = len(memory.embedding)

        return memory if not updates else memory.model_copy(update=updates)

    def _prepare_memory_for_write(self, memory: MemoryCreate, *, embed: bool) -> MemoryCreate:
        if embed:
            return self._embed_memory(memory)

        if memory.embedding is None:
            return memory

        actual_dim = memory.embedding_dim or len(memory.embedding)
        try:
            validate_embedding_dimensions(
                self._configured_embedding_dimension(),
                actual_dim,
                context="configured embedding model",
            )
            validate_embedding_dimensions(
                self._active_embedding_dimension_value(),
                actual_dim,
                context="active vector index",
            )
        except EmbeddingDimensionMismatchError as exc:
            return self._handle_embedding_mismatch(memory, reason=str(exc))

        if memory.embedding_created_at is None:
            return memory.model_copy(update={"embedding_created_at": _utcnow()})
        return memory

    def _embed_memory(self, memory: MemoryCreate) -> MemoryCreate:
        provider = self._embedding_provider()
        text = build_embedding_text(
            memory,
            include_heading_path=self.settings.chunking.include_heading_path,
            include_frontmatter=self.settings.chunking.include_frontmatter_in_embedding,
        )
        embedded = provider.embed_text(text)

        validate_embedding_dimensions(
            self._configured_embedding_dimension(),
            embedded.dim,
            context="configured embedding model",
        )
        validate_embedding_dimensions(
            self._active_embedding_dimension_value(),
            embedded.dim,
            context="active vector index",
        )

        return memory.model_copy(
            update={
                "embedding": embedded.vector,
                "embedding_model": embedded.model,
                "embedding_model_version": embedded.model_version,
                "embedding_dim": embedded.dim,
                "embedding_created_at": embedded.created_at,
            }
        )

    def _handle_embedding_mismatch(self, memory: MemoryCreate, *, reason: str) -> MemoryCreate:
        policy = self.settings.embeddings.dimension_mismatch
        if policy == "error":
            raise EmbeddingDimensionMismatchError(reason)
        if policy == "quarantine":
            return self._quarantine_embedding(memory, reason=reason)
        if policy == "reembed":
            stripped = memory.model_copy(
                update={
                    "embedding": None,
                    "embedding_model": None,
                    "embedding_model_version": None,
                    "embedding_dim": None,
                    "embedding_created_at": None,
                }
            )
            return self._embed_memory(stripped)
        raise PersistenceError(f"Unsupported dimension mismatch policy: {policy}")

    def _quarantine_embedding(self, memory: MemoryCreate, *, reason: str) -> MemoryCreate:
        metadata = dict(memory.metadata)
        metadata["embedding_quarantined"] = True
        metadata["embedding_quarantine_reason"] = reason
        metadata["embedding_quarantine_original_dim"] = memory.embedding_dim or (
            len(memory.embedding) if memory.embedding is not None else None
        )
        if memory.embedding_model is not None:
            metadata["embedding_quarantine_original_model"] = memory.embedding_model
        if memory.embedding_model_version is not None:
            metadata["embedding_quarantine_original_model_version"] = memory.embedding_model_version

        return memory.model_copy(
            update={
                "embedding": None,
                "embedding_model": None,
                "embedding_model_version": None,
                "embedding_dim": None,
                "embedding_created_at": None,
                "metadata": metadata,
            }
        )

    def _embedding_provider(self) -> FastEmbedProvider:
        if self._embedding_provider_instance is not None:
            return self._embedding_provider_instance

        provider_name = self.settings.embeddings.provider.lower()
        if provider_name != "fastembed":
            raise PersistenceError(
                f"Unsupported embedding provider: {self.settings.embeddings.provider}"
            )

        self._embedding_provider_instance = FastEmbedProvider(
            model=self.settings.embeddings.model,
            model_version=self.settings.embeddings.model_version,
            batch_size=self.settings.embeddings.batch_size,
            normalize=self.settings.embeddings.normalize,
        )
        return self._embedding_provider_instance

    def _embed_search_query(self, text: str) -> list[float]:
        return self._embedding_provider().embed_text(text).vector

    def _scoring_weights(self) -> dict[str, float]:
        weights = self.settings.scoring.weights
        configured = weights.model_dump()
        if not self.settings.retrieval.graph_expansion_enabled:
            configured["graph"] = 0.0
        return configured

    def _configured_embedding_dimension(self) -> int:
        dimension = self.settings.embeddings.dim
        if dimension is None:
            raise PersistenceError("MemoryStoreSettings.embeddings.dim must be configured.")
        return dimension

    def _active_embedding_dimension_value(self) -> int:
        self._ensure_repository()
        if self._active_embedding_dimension is not None:
            return self._active_embedding_dimension

        handle = self._database_handle
        if handle is None:
            raise PersistenceError("Database handle is not available.")

        self._active_embedding_dimension = validate_active_index_dimension(
            handle.database,
            self._configured_embedding_dimension(),
        )
        return self._active_embedding_dimension

    def _later_phase_only(self, capability: str) -> NoReturn:
        raise MemoryStoreError(
            f"{capability} is not implemented yet. "
            "Currently available: lifecycle controls, deterministic markdown ingestion, "
            "embeddings safety, CRUD, health, and stats. "
        )
