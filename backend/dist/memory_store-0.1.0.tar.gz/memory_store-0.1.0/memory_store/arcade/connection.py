"""ArcadeDB embedded connection and lifecycle helpers."""

from __future__ import annotations

from dataclasses import dataclass
from importlib.util import find_spec
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ..config import DatabaseSettings
from ..errors import PersistenceError

if TYPE_CHECKING:
    from arcadedb_embedded import Database
else:
    Database = Any


@dataclass(slots=True)
class ArcadeConnectionSettings:
    path: Path
    create_if_missing: bool = True
    embedded_single_process: bool = True

    @classmethod
    def from_database_settings(cls, settings: DatabaseSettings) -> "ArcadeConnectionSettings":
        return cls(
            path=settings.path,
            create_if_missing=settings.create_if_missing,
            embedded_single_process=settings.embedded_single_process,
        )


@dataclass(slots=True)
class ArcadeDatabaseHandle:
    settings: ArcadeConnectionSettings
    database_path: Path
    database: Database
    _lock: "ArcadeProcessLock | None" = None

    def close(self) -> None:
        close_error: Exception | None = None
        try:
            self.database.close()
        except Exception as exc:  # pragma: no cover - wrapped by caller in tests
            close_error = exc
        finally:
            if self._lock is not None:
                self._lock.release()

        if close_error is not None:
            raise PersistenceError(f"Failed to close ArcadeDB database: {close_error}") from close_error

    def __enter__(self) -> "ArcadeDatabaseHandle":
        return self

    def __exit__(self, exc_type: object, exc: object, exc_tb: object) -> None:
        self.close()


class ArcadeProcessLock:
    """Best-effort single-process guard for embedded database usage."""

    def __init__(self, lock_path: Path) -> None:
        self._lock_path = lock_path
        self._fd: int | None = None

    def acquire(self) -> None:
        try:
            self._fd = os.open(self._lock_path, os.O_CREAT | os.O_EXCL | os.O_RDWR)
        except FileExistsError as exc:
            raise PersistenceError(
                f"ArcadeDB path is already locked by another process: {self._lock_path}"
            ) from exc

        payload = f"pid={os.getpid()}\n".encode("ascii", errors="ignore")
        os.write(self._fd, payload)

    def release(self) -> None:
        if self._fd is not None:
            os.close(self._fd)
            self._fd = None

        try:
            self._lock_path.unlink(missing_ok=True)
        except OSError:
            return


def arcade_runtime_available() -> bool:
    return find_spec("arcadedb_embedded") is not None


def normalize_database_path(path: str | Path) -> Path:
    return Path(path).expanduser().resolve(strict=False)


def open_arcade_database(settings: ArcadeConnectionSettings) -> ArcadeDatabaseHandle:
    if not arcade_runtime_available():
        raise PersistenceError("arcadedb_embedded is not installed in the current environment.")

    from arcadedb_embedded import DatabaseFactory

    database_path = normalize_database_path(settings.path)
    database_path.parent.mkdir(parents=True, exist_ok=True)

    lock = None
    if settings.embedded_single_process:
        lock = ArcadeProcessLock(database_path.parent / f"{database_path.name}.lock")
        lock.acquire()

    try:
        factory = DatabaseFactory(str(database_path))
        if factory.exists():
            database = factory.open()
        elif settings.create_if_missing:
            database = factory.create()
        else:
            raise PersistenceError(f"ArcadeDB database does not exist: {database_path}")
    except Exception as exc:
        if lock is not None:
            lock.release()
        raise PersistenceError(f"Failed to open ArcadeDB database at {database_path}: {exc}") from exc

    return ArcadeDatabaseHandle(
        settings=settings,
        database_path=database_path,
        database=database,
        _lock=lock,
    )
